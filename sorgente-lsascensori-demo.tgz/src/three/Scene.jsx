// Realistic elevator shaft: concrete walls, T-guide rails with brackets, steel ropes,
// counterweight, landing slabs, and a stainless cabin with LED ceiling, mirror and car operating panel.
// The cabin travels between floors driven by scroll (scene.floor / scene.doors in store.js).
import { useMemo, useRef, useEffect } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js'
import { scene, isMobile, reducedMotion, FLOORS, FLOOR_H } from '../store'

// ---------- procedural textures (generated once on a canvas: no image downloads)
function canvasTex(w, h, draw, repeat = [1, 1], srgb = true) {
  const c = document.createElement('canvas')
  c.width = w; c.height = h
  draw(c.getContext('2d'), w, h)
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(...repeat)
  t.anisotropy = 4
  if (srgb) t.colorSpace = THREE.SRGBColorSpace
  return t
}

function useTextures() {
  return useMemo(() => {
    // Rough poured concrete with formwork lines and speckles
    const concrete = canvasTex(512, 512, (g, w, h) => {
      g.fillStyle = '#77736d'; g.fillRect(0, 0, w, h)
      for (let i = 0; i < 9000; i++) {
        const v = 90 + Math.random() * 60
        g.fillStyle = `rgba(${v},${v - 3},${v - 7},${Math.random() * 0.35})`
        const s = Math.random() * 3 + 0.5
        g.fillRect(Math.random() * w, Math.random() * h, s, s)
      }
      for (let i = 0; i < 40; i++) { // stains
        const x = Math.random() * w, y = Math.random() * h, r = 20 + Math.random() * 70
        const gr = g.createRadialGradient(x, y, 0, x, y, r)
        gr.addColorStop(0, `rgba(40,38,35,${Math.random() * 0.12})`); gr.addColorStop(1, 'rgba(40,38,35,0)')
        g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2)
      }
      g.strokeStyle = 'rgba(30,28,26,.35)'; g.lineWidth = 2
      g.beginPath(); g.moveTo(0, h * 0.5); g.lineTo(w, h * 0.5); g.moveTo(w * 0.5, 0); g.lineTo(w * 0.5, h); g.stroke()
      for (const [x, y] of [[w * .25, h * .25], [w * .75, h * .25], [w * .25, h * .75], [w * .75, h * .75]]) { // tie holes
        g.fillStyle = 'rgba(25,24,22,.55)'; g.beginPath(); g.arc(x, y, 5, 0, 7); g.fill()
      }
    }, [2, 2])
    // Brushed stainless steel (vertical grain)
    const brushed = canvasTex(256, 512, (g, w, h) => {
      g.fillStyle = '#b9bec4'; g.fillRect(0, 0, w, h)
      for (let i = 0; i < 1400; i++) {
        const v = 150 + Math.random() * 90
        g.strokeStyle = `rgba(${v},${v + 3},${v + 8},${0.08 + Math.random() * 0.15})`
        g.lineWidth = Math.random() * 1.2 + 0.2
        const x = Math.random() * w
        g.beginPath(); g.moveTo(x, 0); g.lineTo(x + (Math.random() - 0.5) * 3, h); g.stroke()
      }
    })
    // Dark granite floor for the cabin
    const granite = canvasTex(256, 256, (g, w, h) => {
      g.fillStyle = '#1d1e21'; g.fillRect(0, 0, w, h)
      for (let i = 0; i < 4000; i++) {
        const v = Math.random() < 0.08 ? 160 : 40 + Math.random() * 40
        g.fillStyle = `rgba(${v},${v},${v + 4},${0.4 + Math.random() * 0.5})`
        g.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5)
      }
    }, [1.5, 1.5])
    // Yellow/black hazard stripes (pit buffers, car-top balustrade)
    const hazard = canvasTex(128, 128, (g, w, h) => {
      g.fillStyle = '#f2b705'; g.fillRect(0, 0, w, h)
      g.fillStyle = '#121212'
      for (let i = -2; i < 4; i++) { g.beginPath(); g.moveTo(i * 64, 0); g.lineTo(i * 64 + 32, 0); g.lineTo(i * 64 + 32 + 128, h); g.lineTo(i * 64 + 128, h); g.fill() }
    }, [2, 1])
    return { concrete, brushed, granite, hazard }
  }, [])
}

// Stencilled floor numbers painted on the shaft wall (as installers do)
function floorLabelTex(n) {
  return canvasTex(256, 256, (g, w, h) => {
    g.clearRect(0, 0, w, h)
    g.fillStyle = 'rgba(230,226,218,.82)'
    g.font = '900 150px "Archivo", "Arial Narrow", Arial, sans-serif'
    g.textAlign = 'center'; g.textBaseline = 'middle'
    g.fillText(n === 0 ? 'T' : String(n), w / 2, h / 2 + 6)
    g.font = '700 26px "Archivo", Arial, sans-serif'
    g.fillText(n === 0 ? 'PIANO TERRA' : `PIANO ${n}`, w / 2, h - 26)
  }, [1, 1])
}

import { DOTS } from '../components/dots'

function drawDisplay(g, w, h, label, dir) {
  g.fillStyle = '#050608'; g.fillRect(0, 0, w, h)
  const cell = 9
  const draw = (glyph, ox, oy, on) => {
    DOTS[glyph].forEach((row, y) => [...row].forEach((b, x) => {
      g.fillStyle = b === '1' ? on : 'rgba(255,60,60,.07)'
      g.beginPath(); g.arc(ox + x * cell, oy + y * cell, 3.4, 0, 7); g.fill()
    }))
  }
  if (dir) draw(dir > 0 ? 'U' : 'D', 14, 40, '#ff3b3b')
  draw(label, 70, 40, '#ff3b3b')
}

// ---------- materials (shared)
function useMaterials(tx) {
  return useMemo(() => ({
    concrete: new THREE.MeshStandardMaterial({ map: tx.concrete, roughness: 0.95, metalness: 0, color: '#9a958d' }),
    slab: new THREE.MeshStandardMaterial({ roughness: 0.92, color: '#5e5d5a' }),
    rail: new THREE.MeshStandardMaterial({ color: '#4c5157', metalness: 0.85, roughness: 0.38 }),
    railFace: new THREE.MeshStandardMaterial({ color: '#c9ced4', metalness: 1, roughness: 0.22 }),
    bracket: new THREE.MeshStandardMaterial({ color: '#2c3a46', metalness: 0.4, roughness: 0.6 }),
    steel: new THREE.MeshStandardMaterial({ map: tx.brushed, color: '#d6dade', metalness: 1, roughness: 0.32 }),
    steelDark: new THREE.MeshStandardMaterial({ color: '#2a2d31', metalness: 0.7, roughness: 0.45 }),
    frame: new THREE.MeshStandardMaterial({ color: '#3a3f45', metalness: 0.6, roughness: 0.5 }),
    mirror: new THREE.MeshStandardMaterial({ color: '#ffffff', metalness: 1, roughness: 0.04 }),
    floor: new THREE.MeshStandardMaterial({ map: tx.granite, roughness: 0.35, metalness: 0.1 }),
    led: new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#eaf4ff', emissiveIntensity: 2.2, roughness: 1 }),
    ledStrip: new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#fff6e6', emissiveIntensity: 1.6 }),
    rope: new THREE.MeshStandardMaterial({ color: '#8a8f95', metalness: 0.9, roughness: 0.45 }),
    hazard: new THREE.MeshStandardMaterial({ map: tx.hazard, roughness: 0.7 }),
    weight: new THREE.MeshStandardMaterial({ color: '#2b2e33', metalness: 0.3, roughness: 0.8 }),
    red: new THREE.MeshStandardMaterial({ color: '#d7262e', roughness: 0.5, metalness: 0.2 }),
    glass: new THREE.MeshStandardMaterial({ color: '#0b0d10', metalness: 0.6, roughness: 0.1 }),
    btn: new THREE.MeshStandardMaterial({ color: '#cfd4da', metalness: 1, roughness: 0.25, emissive: '#5a7cff', emissiveIntensity: 0.15 }),
  }), [tx])
}

// Shaft geometry (meters)
const SW = 2.6     // inner width (x)
const SD = 2.0     // inner depth (z)
const CAR_X = 0.25 // cabin centre x (counterweight sits on the left)
const CW = 1.15, CH = 2.2, CD = 1.35 // cabin inner size
const TOP = (FLOORS - 1) * FLOOR_H + 3.6 // machine level
const FP = 0.2              // front panel width each side
const OW = CW - 2 * FP      // clear door opening
const DOOR_PANELS = [-1, 1].flatMap((s) => [
  { closed: s * OW / 8, open: s * (OW / 2 + FP / 2), z: -0.01 },      // inner (fast) panel
  { closed: s * 3 * OW / 8, open: s * (OW / 2 + FP / 2), z: -0.035 }, // outer (slow) panel
])

function Rail({ x, m, height, face = 1 }) {
  // T-profile: web pointing at the cabin + flange against the bracket
  return (
    <group position={[x, height / 2 - 1.4, 0]}>
      <mesh material={m.rail}><boxGeometry args={[0.012, height, 0.11]} /></mesh>
      <mesh material={m.railFace} position={[face * 0.035, 0, 0]}><boxGeometry args={[0.07, height, 0.016]} /></mesh>
    </group>
  )
}

function Shaft({ m, tx }) {
  const H = TOP + 4
  const labels = useMemo(() => Array.from({ length: FLOORS }, (_, i) => floorLabelTex(i)), [])
  const bracketYs = useMemo(() => {
    const a = []
    for (let y = -0.6; y < TOP; y += isMobile ? 2.2 : 1.6) a.push(y)
    return a
  }, [])
  const railH = TOP + 1.4
  const concreteBack = useMemo(() => { const t = tx.concrete.clone(); t.repeat.set(SW / 1.6, H / 1.6); t.needsUpdate = true; return t }, [tx, H])
  const concreteSide = useMemo(() => { const t = tx.concrete.clone(); t.repeat.set(SD / 1.6, H / 1.6); t.needsUpdate = true; return t }, [tx, H])
  return (
    <group>
      {/* walls */}
      <mesh position={[0, H / 2 - 2, -SD / 2]} receiveShadow>
        <planeGeometry args={[SW, H]} />
        <meshStandardMaterial map={concreteBack} roughness={0.95} color="#8e8981" />
      </mesh>
      <mesh position={[-SW / 2, H / 2 - 2, 0]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[SD, H]} />
        <meshStandardMaterial map={concreteSide} roughness={0.95} color="#7f7a73" />
      </mesh>
      <mesh position={[SW / 2, H / 2 - 2, 0]} rotation={[0, -Math.PI / 2, 0]}>
        <planeGeometry args={[SD, H]} />
        <meshStandardMaterial map={concreteSide} roughness={0.95} color="#837e77" />
      </mesh>
      {/* pit floor + buffers */}
      <mesh position={[0, -1.4, 0]} rotation={[-Math.PI / 2, 0, 0]} material={m.concrete}><planeGeometry args={[SW, SD]} /></mesh>
      {[CAR_X - 0.3, CAR_X + 0.3, -SW / 2 + 0.32].map((x, i) => (
        <group key={i} position={[x, -1.4, 0.05]}>
          <mesh position={[0, 0.18, 0]} material={m.hazard}><cylinderGeometry args={[0.07, 0.09, 0.36, 16]} /></mesh>
          <mesh position={[0, 0.38, 0]} material={m.steelDark}><cylinderGeometry args={[0.09, 0.09, 0.04, 16]} /></mesh>
        </group>
      ))}
      {/* car guide rails (left/right of cabin) and counterweight rails */}
      <Rail x={CAR_X - CW / 2 - 0.12} m={m} height={railH} face={1} />
      <Rail x={CAR_X + CW / 2 + 0.12} m={m} height={railH} face={-1} />
      <group position={[-SW / 2 + 0.32, 0, 0]}>
        <mesh material={m.rail} position={[0, railH / 2 - 1.4, -0.24]}><boxGeometry args={[0.05, railH, 0.04]} /></mesh>
        <mesh material={m.rail} position={[0, railH / 2 - 1.4, 0.24]}><boxGeometry args={[0.05, railH, 0.04]} /></mesh>
      </group>
      {/* rail brackets anchored to the walls */}
      {bracketYs.map((y) => (
        <group key={y} position={[0, y, 0]}>
          {[CAR_X - CW / 2 - 0.12, CAR_X + CW / 2 + 0.12].map((x) => (
            <group key={x}>
              <mesh material={m.bracket} position={[x, 0, -SD / 4 - 0.04]}><boxGeometry args={[0.1, 0.1, SD / 2 - 0.08]} /></mesh>
              <mesh material={m.bracket} position={[x, 0, -SD / 2 + 0.01]}><boxGeometry args={[0.24, 0.2, 0.02]} /></mesh>
            </group>
          ))}
          <mesh material={m.bracket} position={[-SW / 2 + 0.16, 0, 0]}>
            <boxGeometry args={[0.32, 0.08, 0.6]} />
          </mesh>
        </group>
      ))}
      {/* landing slabs with sill + door jambs at each floor, LED shaft lights and painted numbers */}
      {Array.from({ length: FLOORS }, (_, i) => {
        const y = i * FLOOR_H
        return (
          <group key={i} position={[0, y, 0]}>
            <mesh material={m.slab} position={[0, -0.16, SD / 2 + 0.25]}><boxGeometry args={[SW + 1.6, 0.32, 0.5]} /></mesh>
            <mesh material={m.steel} position={[CAR_X, 0.005, SD / 2 + 0.03]}><boxGeometry args={[CW + 0.2, 0.02, 0.08]} /></mesh>
            {[-1, 1].map((s) => (
              <mesh key={s} material={m.steelDark} position={[CAR_X + s * (CW / 2 + 0.12), 1.08, SD / 2 + 0.06]}><boxGeometry args={[0.07, 2.16, 0.06]} /></mesh>
            ))}
            <mesh material={m.steelDark} position={[CAR_X, 2.2, SD / 2 + 0.06]}><boxGeometry args={[CW + 0.31, 0.1, 0.06]} /></mesh>
            <mesh position={[-0.55, 1.6, -SD / 2 + 0.005]}>
              <planeGeometry args={[0.8, 0.8]} />
              <meshBasicMaterial map={labels[i]} transparent toneMapped={false} opacity={0.85} />
            </mesh>
            <mesh material={m.ledStrip} position={[0.75, 2.6, -SD / 2 + 0.02]}><boxGeometry args={[0.45, 0.04, 0.02]} /></mesh>
          </group>
        )
      })}
      {/* machine room level: gearless motor on a bedplate + traction sheave */}
      <group position={[-0.25, TOP, -0.1]}>
        <mesh material={m.bracket} position={[0, -0.1, 0]}><boxGeometry args={[SW, 0.14, 0.5]} /></mesh>
        <mesh material={m.steelDark} position={[0.15, 0.32, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.32, 0.32, 0.38, 28]} /></mesh>
        <mesh material={m.red} position={[0.38, 0.32, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.28, 0.28, 0.1, 28]} /></mesh>
        <mesh material={m.rail} position={[-0.12, 0.32, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.25, 0.25, 0.16, 28]} /></mesh>
      </group>
    </group>
  )
}

function Cabin({ m }) {
  const car = useRef()
  const cw = useRef()
  const doors = useRef([])
  const ropesCar = useRef()
  const ropesCw = useRef()
  const light = useRef()
  const disp = useMemo(() => {
    const c = document.createElement('canvas'); c.width = 128; c.height = 128
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace
    return { c, g: c.getContext('2d'), t, last: '' }
  }, [])
  const state = useRef({ y: scene.floor * FLOOR_H, doors: scene.doors, v: 0 })

  useFrame((_, dt) => {
    const s = state.current
    const targetY = scene.floor * FLOOR_H
    const k = reducedMotion ? 1 : 1 - Math.exp(-3.2 * Math.min(dt, 0.05))
    const prev = s.y
    s.y += (targetY - s.y) * k
    s.v = (s.y - prev) / Math.max(dt, 1e-3)
    s.doors += (scene.doors - s.doors) * (reducedMotion ? 1 : 1 - Math.exp(-6 * Math.min(dt, 0.05)))
    car.current.position.y = s.y
    // counterweight travels opposite to the cabin
    const cwY = (FLOORS - 1) * FLOOR_H - s.y + 0.6
    cw.current.position.y = cwY
    const open = Math.min(Math.max(s.doors, 0), 1)
    DOOR_PANELS.forEach((d, i) => { if (doors.current[i]) doors.current[i].position.x = d.closed + (d.open - d.closed) * open })
    // ropes from crosshead / counterweight up to the sheave
    const carTop = s.y + CH + 0.35
    const lenCar = Math.max(TOP + 0.32 - carTop, 0.01)
    ropesCar.current.scale.y = lenCar
    ropesCar.current.position.y = carTop + lenCar / 2
    const cwTop = cwY + 1.3
    const lenCw = Math.max(TOP + 0.32 - cwTop, 0.01)
    ropesCw.current.scale.y = lenCw
    ropesCw.current.position.y = cwTop + lenCw / 2
    light.current.intensity = 2 + open * 4
    // floor display
    const near = Math.round(s.y / FLOOR_H)
    const dir = Math.abs(s.v) > 0.15 ? Math.sign(s.v) : 0
    const label = near === 0 ? 'T' : String(near)
    const key = label + dir
    if (key !== disp.last) {
      disp.last = key
      drawDisplay(disp.g, 128, 128, label, dir)
      disp.t.needsUpdate = true
    }
  })

  const wallT = 0.03
  return (
    <group>
      <group ref={car} position={[CAR_X, 0, 0]}>
        {/* floor */}
        <mesh material={m.floor} position={[0, -0.03, 0]}><boxGeometry args={[CW, 0.06, CD]} /></mesh>
        <mesh material={m.steelDark} position={[0, -0.12, 0]}><boxGeometry args={[CW + 0.1, 0.12, CD + 0.06]} /></mesh>
        {/* toe guard */}
        <mesh material={m.steelDark} position={[0, -0.45, CD / 2 + 0.02]}><boxGeometry args={[CW, 0.6, 0.015]} /></mesh>
        {/* back wall: mirror between steel panels + handrail */}
        <mesh material={m.steel} position={[0, CH / 2, -CD / 2]}><boxGeometry args={[CW, CH, wallT]} /></mesh>
        <mesh material={m.mirror} position={[0, 1.35, -CD / 2 + 0.02]}><boxGeometry args={[CW - 0.24, 1.3, 0.006]} /></mesh>
        <mesh material={m.railFace} position={[0, 0.9, -CD / 2 + 0.07]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.018, 0.018, CW - 0.2, 12]} /></mesh>
        {[-1, 1].map((s) => (
          <mesh key={s} material={m.railFace} position={[s * (CW / 2 - 0.1), 0.9, -CD / 2 + 0.04]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.012, 0.012, 0.06, 8]} /></mesh>
        ))}
        {/* side walls with vertical panel joints */}
        {[-1, 1].map((s) => (
          <group key={s} position={[s * CW / 2, CH / 2, 0]}>
            <mesh material={m.steel}><boxGeometry args={[wallT, CH, CD]} /></mesh>
            {[-0.33, 0.33].map((z) => (
              <mesh key={z} material={m.steelDark} position={[-s * 0.016, 0, z * CD / 2 * 1.2]}><boxGeometry args={[0.004, CH, 0.008]} /></mesh>
            ))}
          </group>
        ))}
        {/* car operating panel: dark glass column with display + buttons */}
        <group position={[CW / 2 - 0.02, 1.1, 0.22]}>
          <mesh material={m.glass}><boxGeometry args={[0.012, 1.5, 0.2]} /></mesh>
          <mesh position={[-0.008, 0.52, 0]} rotation={[0, -Math.PI / 2, 0]}>
            <planeGeometry args={[0.14, 0.14]} />
            <meshBasicMaterial map={disp.t} toneMapped={false} />
          </mesh>
          {Array.from({ length: FLOORS }, (_, i) => (
            <mesh key={i} material={m.btn} position={[-0.009, 0.2 - i * 0.09, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.022, 0.022, 0.008, 18]} /></mesh>
          ))}
          <mesh material={m.red} position={[-0.009, -0.42, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.026, 0.026, 0.01, 18]} /></mesh>
        </group>
        {/* ceiling: steel frame + LED panel */}
        <mesh material={m.steelDark} position={[0, CH + 0.02, 0]}><boxGeometry args={[CW, 0.04, CD]} /></mesh>
        <mesh material={m.led} position={[0, CH - 0.005, -0.02]}><boxGeometry args={[CW - 0.22, 0.012, CD - 0.3]} /></mesh>
        <pointLight ref={light} position={[0, CH - 0.25, 0.1]} intensity={4} distance={4.5} decay={1.6} color="#eef5ff" />
        {/* car doors: centre-opening telescopic (2 panels per side) sliding behind the front panels */}
        <group position={[0, CH / 2 - 0.05, CD / 2]}>
          {DOOR_PANELS.map((d, i) => (
            <mesh key={i} ref={(el) => (doors.current[i] = el)} material={m.steel} position={[d.closed, 0, d.z]}>
              <boxGeometry args={[OW / 4 + 0.012, CH - 0.1, 0.02]} />
            </mesh>
          ))}
          {[-1, 1].map((s) => (
            <mesh key={s} material={m.steel} position={[s * (OW / 2 + FP / 2), 0.05, 0.03]}><boxGeometry args={[FP, CH, 0.03]} /></mesh>
          ))}
          {[-1, 1].map((s) => (
            <mesh key={'e' + s} material={m.steelDark} position={[s * (OW / 2 + 0.004), 0.05, 0.048]}><boxGeometry args={[0.008, CH, 0.004]} /></mesh>
          ))}
        </group>
        {/* sling: stiles, crosshead, guide shoes, car-top balustrade */}
        {[-1, 1].map((s) => (
          <group key={s}>
            <mesh material={m.frame} position={[s * (CW / 2 + 0.06), CH / 2, 0]}><boxGeometry args={[0.06, CH + 0.5, 0.12]} /></mesh>
            {[CH + 0.26, -0.22].map((y) => (
              <mesh key={y} material={m.steelDark} position={[s * (CW / 2 + 0.1), y, 0]}><boxGeometry args={[0.06, 0.14, 0.12]} /></mesh>
            ))}
          </group>
        ))}
        <mesh material={m.frame} position={[0, CH + 0.3, 0]}><boxGeometry args={[CW + 0.18, 0.14, 0.14]} /></mesh>
        <mesh material={m.hazard} position={[0, CH + 0.55, -CD / 2 + 0.03]}><boxGeometry args={[CW - 0.1, 0.06, 0.03]} /></mesh>
        {[-1, 1].map((s) => (
          <mesh key={s} material={m.hazard} position={[s * (CW / 2 - 0.08), CH + 0.3, -CD / 2 + 0.03]}><boxGeometry args={[0.03, 0.55, 0.03]} /></mesh>
        ))}
        <mesh material={m.steelDark} position={[0.3, CH + 0.12, 0.25]}><boxGeometry args={[0.28, 0.18, 0.2]} /></mesh>
      </group>
      {/* ropes */}
      <group ref={ropesCar} position={[CAR_X, 0, 0]}>
        {[-0.06, -0.02, 0.02, 0.06].map((x) => (
          <mesh key={x} material={m.rope} position={[x, 0, 0]}><cylinderGeometry args={[0.006, 0.006, 1, 6]} /></mesh>
        ))}
      </group>
      <group ref={ropesCw} position={[-SW / 2 + 0.32, 0, 0]}>
        {[-0.06, -0.02, 0.02, 0.06].map((x) => (
          <mesh key={x} material={m.rope} position={[0, 0, x]}><cylinderGeometry args={[0.006, 0.006, 1, 6]} /></mesh>
        ))}
      </group>
      {/* counterweight: frame with stacked filler blocks */}
      <group ref={cw} position={[-SW / 2 + 0.32, 0, 0]}>
        {[-1, 1].map((s) => (
          <mesh key={s} material={m.frame} position={[0, 0.6, s * 0.21]}><boxGeometry args={[0.1, 1.5, 0.04]} /></mesh>
        ))}
        {Array.from({ length: 9 }, (_, i) => (
          <mesh key={i} material={m.weight} position={[0, 0.0 + i * 0.13, 0]}><boxGeometry args={[0.16, 0.115, 0.38]} /></mesh>
        ))}
        <mesh material={m.red} position={[0, 1.33, 0]}><boxGeometry args={[0.12, 0.08, 0.44]} /></mesh>
      </group>
    </group>
  )
}

function Rig() {
  const { camera, size } = useThree()
  const s = useRef({ y: scene.floor * FLOOR_H })
  useFrame((_, dt) => {
    const k = reducedMotion ? 1 : 1 - Math.exp(-2.4 * Math.min(dt, 0.05))
    s.current.y += (scene.floor * FLOOR_H - s.current.y) * k
    const px = scene.pointer.x, py = scene.pointer.y
    const wide = size.width > 820
    const y = s.current.y
    camera.position.set(
      (wide ? 2.2 : 1.1) + px * 0.5,
      y + (wide ? 1.75 : 1.5) - py * 0.25,
      wide ? 5.6 : 6.6
    )
    camera.lookAt(wide ? -0.9 : CAR_X - 0.05, y + (wide ? 1.15 : 0.55), 0)
  })
  return null
}

function Env() {
  const { gl, scene: s } = useThree()
  useEffect(() => {
    const pm = new THREE.PMREMGenerator(gl)
    const rt = pm.fromScene(new RoomEnvironment(), 0.04)
    s.environment = rt.texture
    s.environmentIntensity = 0.55
    return () => { rt.dispose(); pm.dispose() }
  }, [gl, s])
  return null
}

function Pointer() {
  const { invalidate } = useThree()
  useEffect(() => {
    scene.invalidate = invalidate
    if (reducedMotion || isMobile) return
    const on = (e) => {
      scene.pointer.x = (e.clientX / window.innerWidth) * 2 - 1
      scene.pointer.y = (e.clientY / window.innerHeight) * 2 - 1
    }
    window.addEventListener('pointermove', on, { passive: true })
    return () => window.removeEventListener('pointermove', on)
  }, [invalidate])
  return null
}

function World() {
  const tx = useTextures()
  const m = useMaterials(tx)
  return (
    <>
      <Shaft m={m} tx={tx} />
      <Cabin m={m} />
    </>
  )
}

export default function Scene() {
  return (
    <div className="canvas-wrap" aria-hidden="true">
      <Canvas
        dpr={[1, isMobile ? 1.5 : 1.75]}
        camera={{ position: [2, 1.7, 5.6], fov: isMobile ? 46 : 38, near: 0.1, far: 60 }}
        gl={{ antialias: !isMobile, powerPreference: 'high-performance', alpha: false }}
        frameloop={reducedMotion ? 'demand' : 'always'}
        onCreated={({ gl, scene: s }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping
          gl.toneMappingExposure = 1.05
          s.background = new THREE.Color('#0b0c0e')
          s.fog = new THREE.Fog('#0b0c0e', 7, 16)
        }}
      >
        <Env />
        <Rig />
        <Pointer />
        <hemisphereLight args={['#dfe7f0', '#2a2622', 0.55]} />
        <directionalLight position={[3, 8, 6]} intensity={1.1} color="#fff4e6" />
        <World />
      </Canvas>
    </div>
  )
}

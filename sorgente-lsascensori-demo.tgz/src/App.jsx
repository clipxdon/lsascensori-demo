import { lazy, Suspense, useEffect, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Lenis from 'lenis'
import SplitText from './components/SplitText'
import LedDisplay from './components/LedDisplay'
import Glyph from './components/Glyph'
import Magnetic from './components/Magnetic'
import logoSmall from './assets/logo-dark-160.webp'
import logoBig from './assets/logo-dark-480.webp'
import { COMPANY, SERVICES, SYSTEMS, STEPS, AREAS } from './content'
import { scene, reducedMotion } from './store'

gsap.registerPlugin(ScrollTrigger)
const Scene = lazy(() => import('./three/Scene'))

const smooth = (a, b, x) => { const t = Math.min(Math.max((x - a) / (b - a), 0), 1); return t * t * (3 - 2 * t) }

// Scroll -> elevator: each section is a floor. The cabin waits with doors open while you read,
// closes the doors, then travels to the next floor during the last part of the section.
function useElevator(setFloor) {
  useEffect(() => {
    const els = [...document.querySelectorAll('[data-floor]')]
    let last = -1, lastDir = 0
    const update = () => {
      const c = window.scrollY + window.innerHeight * 0.5
      let i = 0
      for (let k = 0; k < els.length; k++) if (els[k].offsetTop <= c) i = k
      const el = els[i]
      const t = Math.min(Math.max((c - el.offsetTop) / el.offsetHeight, 0), 1)
      const lastFloor = i === els.length - 1
      const travel = lastFloor ? 0 : smooth(0.66, 1, t)
      const doors = lastFloor
        ? smooth(0.0, 0.12, t)
        : i === 0
          ? 1 - smooth(0.5, 0.64, t)
          : smooth(0.02, 0.16, t) * (1 - smooth(0.5, 0.64, t))
      scene.floor = i + travel
      scene.doors = doors
      const shown = Math.round(scene.floor)
      const dir = travel > 0.02 && travel < 0.98 ? 1 : 0
      if (shown !== last || dir !== lastDir) { last = shown; lastDir = dir; setFloor({ n: shown, dir }) }
      if (scene.invalidate) scene.invalidate()
    }
    update()
    window.addEventListener('scroll', update, { passive: true })
    window.addEventListener('resize', update)
    return () => { window.removeEventListener('scroll', update); window.removeEventListener('resize', update) }
  }, [setFloor])
}

function useLenis() {
  useEffect(() => {
    if (reducedMotion) return
    const lenis = new Lenis({ duration: 1.15, easing: (t) => 1 - Math.pow(1 - t, 4), smoothWheel: true })
    lenis.on('scroll', ScrollTrigger.update)
    const raf = (t) => lenis.raf(t * 1000)
    gsap.ticker.add(raf)
    gsap.ticker.lagSmoothing(0)
    window.__lenis = lenis
    return () => { gsap.ticker.remove(raf); lenis.destroy() }
  }, [])
}

const go = (id) => (e) => {
  e.preventDefault()
  const el = document.getElementById(id)
  if (window.__lenis) window.__lenis.scrollTo(el, { offset: 0, duration: 1.8 })
  else el.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth' })
}

const NAV = [
  { id: 'servizi', n: 1, label: 'Servizi' },
  { id: 'impianti', n: 2, label: 'Impianti' },
  { id: 'metodo', n: 3, label: 'Come lavoriamo' },
  { id: 'perche', n: 4, label: 'Perché noi' },
  { id: 'contatti', n: 5, label: 'Contatti' },
]

function Logo({ big = false }) {
  return <img src={big ? logoBig : logoSmall} alt="" className={big ? 'logo-img big' : 'logo-img'} width={big ? 140 : 40} height={big ? 160 : 46} decoding="async" />
}

function Nav({ floor }) {
  const [open, setOpen] = useState(false)
  return (
    <header className="nav">
      <a href="#top" onClick={go('top')} className="brand" aria-label="LS Ascensori, torna su">
        <Logo />
        <span>LS<b>Ascensori</b></span>
      </a>
      <nav aria-label="Piani" className={open ? 'open' : ''}>
        {NAV.map((l) => (
          <a key={l.id} href={`#${l.id}`} onClick={(e) => { setOpen(false); go(l.id)(e) }} className={floor.n === l.n ? 'active' : ''}>
            <span className="nav-n">{l.n}</span>{l.label}
          </a>
        ))}
      </nav>
      <div className="nav-right">
        <LedDisplay floor={floor.n} dir={floor.dir} />
        <a className="btn btn-red btn-sm" href={COMPANY.phones[0].href}>Chiama</a>
        <button className="menu-btn" aria-expanded={open} aria-label="Menu" onClick={() => setOpen((v) => !v)}><span /><span /></button>
      </div>
    </header>
  )
}

function FloorTag({ n, label }) {
  return (
    <p className="floor-tag"><span className="ft-n">{n === 0 ? 'T' : n}</span><span>{n === 0 ? 'Piano terra' : `Piano ${n}`} · {label}</span></p>
  )
}

function Hero() {
  const ref = useRef(null)
  useEffect(() => {
    const ctx = gsap.context(() => {
      if (reducedMotion) return
      gsap.from('.hero-in', { opacity: 0, y: 30, duration: 1.2, ease: 'expo.out', stagger: 0.1, delay: 0.7 })
      gsap.from('.hero-line', { scaleY: 0, transformOrigin: 'bottom', duration: 1.6, ease: 'expo.inOut', delay: 0.2 })
      gsap.timeline({ scrollTrigger: { trigger: ref.current, start: 'top top', end: 'bottom top', scrub: true } })
        .to('.hero-title', { yPercent: -18, opacity: 0.15, ease: 'none' }, 0)
    }, ref)
    return () => ctx.revert()
  }, [])
  return (
    <section id="top" className="hero floor" data-floor="0" ref={ref}>
      <div className="hero-copy">
        <FloorTag n={0} label="Ingresso" />
        <h1 className="hero-title" aria-label="LS Ascensori. Si sale, in sicurezza.">
          <SplitText as="span" text="Si sale." className="ht-1" immediate delay={0.25} />
          <SplitText as="span" text="In sicurezza." className="ht-2" immediate delay={0.45} />
        </h1>
        <p className="lead hero-in">Vendita, installazione, manutenzione e riparazione di ascensori, montacarichi, piattaforme elevatrici e servoscala. Da Bra e Cherasco, in tutto il Piemonte.</p>
        <div className="ctas hero-in">
          <Magnetic><a className="btn btn-red" href={COMPANY.phones[0].href}>Chiama {COMPANY.phones[0].label}</a></Magnetic>
          <a className="btn btn-ghost" href="#contatti" onClick={go('contatti')}>Richiedi un preventivo</a>
        </div>
        <p className="badge-24 hero-in"><span className="pulse" aria-hidden="true" />Pronto intervento 24 ore su 24</p>
      </div>
      <span className="hero-line" aria-hidden="true" />
      <a href="#servizi" onClick={go('servizi')} className="scroll-hint">Scorri per salire <span aria-hidden="true">▲</span></a>
    </section>
  )
}

function useReveal(ref, sel, opts = {}) {
  useEffect(() => {
    const ctx = gsap.context(() => {
      if (reducedMotion) return
      gsap.utils.toArray(sel, ref.current).forEach((el, i) =>
        gsap.from(el, {
          y: 50, opacity: 0, duration: 1.1, ease: 'expo.out', delay: (i % 4) * 0.07, ...opts,
          scrollTrigger: { trigger: el, start: 'top 90%', once: true },
        })
      )
    }, ref)
    return () => ctx.revert()
  }, [])
}

function Services() {
  const ref = useRef(null)
  useReveal(ref, '.svc')
  return (
    <section id="servizi" className="floor services" data-floor="1" ref={ref}>
      <div className="panel">
        <FloorTag n={1} label="Servizi" />
        <SplitText text="Dal primo bullone all’ultimo controllo." className="h2" />
        <p className="sub">Un solo referente per tutta la vita dell’impianto: progettiamo, montiamo, controlliamo e interveniamo quando serve.</p>
        <div className="svc-grid">
          {SERVICES.map((s) => (
            <article key={s.n} className={`svc ${s.hot ? 'hot' : ''}`}>
              <span className="svc-n">{s.n}</span>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

function Systems() {
  const ref = useRef(null)
  useReveal(ref, '.sys', { x: 40, y: 0 })
  return (
    <section id="impianti" className="floor systems" data-floor="2" ref={ref}>
      <div className="panel">
        <FloorTag n={2} label="Impianti" />
        <SplitText text="Ogni dislivello ha la sua soluzione." className="h2" />
        <ul className="sys-list">
          {SYSTEMS.map((s, i) => (
            <li key={s.id} className="sys">
              <Glyph name={s.id} />
              <div>
                <h3><span className="sys-i">0{i + 1}</span>{s.title}</h3>
                <p>{s.text}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}

function Method() {
  const ref = useRef(null)
  useEffect(() => {
    const ctx = gsap.context(() => {
      if (reducedMotion) return
      gsap.fromTo('.m-progress', { scaleY: 0 }, { scaleY: 1, ease: 'none', scrollTrigger: { trigger: '.m-list', start: 'top 70%', end: 'bottom 60%', scrub: true } })
      gsap.utils.toArray('.m-step', ref.current).forEach((el) =>
        ScrollTrigger.create({ trigger: el, start: 'top 68%', onEnter: () => el.classList.add('lit'), onLeaveBack: () => el.classList.remove('lit') })
      )
    }, ref)
    return () => ctx.revert()
  }, [])
  return (
    <section id="metodo" className="floor method" data-floor="3" ref={ref}>
      <div className="panel">
        <FloorTag n={3} label="Come lavoriamo" />
        <SplitText text="Cinque fermate, nessuna sorpresa." className="h2" />
        <ol className="m-list">
          <span className="m-progress" aria-hidden="true" />
          {STEPS.map((s, i) => (
            <li key={s.t} className={`m-step ${reducedMotion ? 'lit' : ''}`}>
              <span className="m-btn" aria-hidden="true">{i + 1}</span>
              <div><h3>{s.t}</h3><p>{s.d}</p></div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}

function Why() {
  const ref = useRef(null)
  useReveal(ref, '.why-card')
  return (
    <section id="perche" className="floor why" data-floor="4" ref={ref}>
      <div className="panel">
        <FloorTag n={4} label="Perché noi" />
        <SplitText text="Due tecnici, un numero di telefono." className="h2" />
        <p className="sub">Dietro LS Ascensori ci sono {COMPANY.owners}: quando chiami parli direttamente con chi verrà a lavorare sul tuo impianto.</p>
        <div className="why-grid">
          <div className="why-card big"><span className="why-num">24<small>/7</small></span><p>Pronto intervento, festivi compresi.</p></div>
          <div className="why-card"><Glyph name="shield" /><h3>Materiali di qualità</h3><p>Componenti certificati e ricambi affidabili, per impianti sicuri ed efficienti nel tempo.</p></div>
          <div className="why-card"><Glyph name="ruler" /><h3>Soluzioni su misura</h3><p>Ogni edificio è diverso: adattiamo l’impianto agli spazi, non il contrario.</p></div>
          <div className="why-card"><Glyph name="pin" /><h3>Vicini a te</h3><p>Base tra Bra e Cherasco, operativi in tutto il Piemonte.</p></div>
        </div>
        <div className="areas" aria-label="Zone servite">
          <div className="areas-track">
            {[...AREAS, ...AREAS].map((a, i) => <span key={i} aria-hidden={i >= AREAS.length}>{a}<i>▲</i></span>)}
          </div>
        </div>
      </div>
    </section>
  )
}

function Contact() {
  const ref = useRef(null)
  const [form, setForm] = useState({ nome: '', tel: '', tipo: 'Manutenzione', msg: '' })
  useReveal(ref, '.c-in')
  const mail = `mailto:${COMPANY.email}?subject=${encodeURIComponent('Richiesta dal sito: ' + form.tipo)}&body=${encodeURIComponent(`Nome: ${form.nome}\nTelefono: ${form.tel}\nTipo di richiesta: ${form.tipo}\n\n${form.msg}`)}`
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))
  return (
    <section id="contatti" className="floor contact" data-floor="5" ref={ref}>
      <div className="panel">
        <FloorTag n={5} label="Contatti" />
        <SplitText text="Siamo arrivati. Parliamone." className="h2" />
        <div className="c-grid">
          <div className="c-card c-in">
            <h3>Chiamaci</h3>
            {COMPANY.phones.map((p) => <a key={p.href} className="c-big" href={p.href}>{p.label}</a>)}
            <p className="c-note"><span className="pulse" aria-hidden="true" />Per guasti e persone bloccate rispondiamo 24 ore su 24.</p>
            <h3>Scrivici</h3>
            <a className="c-link" href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a>
            <h3>Sede</h3>
            <p>{COMPANY.legal}<br />{COMPANY.address}<br />{COMPANY.city}</p>
            <div className="c-actions">
              <a className="btn btn-ghost btn-sm" href={COMPANY.maps} target="_blank" rel="noopener">Indicazioni</a>
              <a className="btn btn-ghost btn-sm" href={COMPANY.instagram} target="_blank" rel="noopener">Instagram</a>
            </div>
          </div>
          <form className="c-card c-form c-in" onSubmit={(e) => { e.preventDefault(); window.location.href = mail }}>
            <h3>Richiedi un preventivo</h3>
            <label>Nome<input required value={form.nome} onChange={set('nome')} autoComplete="name" /></label>
            <label>Telefono<input required type="tel" value={form.tel} onChange={set('tel')} autoComplete="tel" /></label>
            <label>Di cosa hai bisogno
              <select value={form.tipo} onChange={set('tipo')}>
                {['Nuovo impianto', 'Manutenzione', 'Riparazione', 'Piattaforma o servoscala', 'Altro'].map((o) => <option key={o}>{o}</option>)}
              </select>
            </label>
            <label>Messaggio<textarea rows="4" value={form.msg} onChange={set('msg')} placeholder="Tipo di edificio, numero di piani, zona…" /></label>
            <button className="btn btn-red" type="submit">Invia richiesta</button>
            <p className="form-note">Il modulo apre il tuo programma di posta con il messaggio già compilato.</p>
          </form>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="brand"><Logo big /></div>
      <p>{COMPANY.legal} · P.IVA {COMPANY.vat} · {COMPANY.address}, {COMPANY.city}</p>
      <p className="demo-note">Bozza dimostrativa di sito web. Contenuti e immagini 3D di esempio.</p>
    </footer>
  )
}

export default function App() {
  const [floor, setFloor] = useState({ n: 0, dir: 0 })
  const [webgl] = useState(() => {
    try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')) } catch { return false }
  })
  useLenis()
  useElevator(setFloor)
  useEffect(() => {
    document.documentElement.classList.toggle('reduced', reducedMotion)
    const t = setTimeout(() => ScrollTrigger.refresh(), 600)
    return () => clearTimeout(t)
  }, [])
  return (
    <>
      <div className="shaft-fallback" aria-hidden="true" />
      {webgl && <Suspense fallback={null}><Scene /></Suspense>}
      <div className="vignette" aria-hidden="true" />
      <Nav floor={floor} />
      <main>
        <Hero />
        <Services />
        <Systems />
        <Method />
        <Why />
        <Contact />
      </main>
      <Footer />
    </>
  )
}

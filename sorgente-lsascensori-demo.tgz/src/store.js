// Shared mutable state: scroll logic writes, the R3F loop reads (no React re-renders).
export const scene = {
  floor: 0,        // target cabin position in floors (continuous)
  doors: 1,        // target doors opening 0..1
  pointer: { x: 0, y: 0 },
  invalidate: null, // set by the canvas (used when motion is reduced)
}

export const FLOORS = 6
export const FLOOR_H = 3.2

export const reducedMotion =
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

export const isMobile =
  typeof window !== 'undefined' && window.matchMedia('(max-width: 820px)').matches

export const PALETTE = {
  ink: '#0E0F11',
  graphite: '#1A1C20',
  steel: '#A9B0B8',
  red: '#D7262E',
  white: '#F3F1EC',
  led: '#EAF4FF',
}

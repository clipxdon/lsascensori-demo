// Dot-matrix floor indicator (5x7 LEDs), like the display above a landing door.
import { DOTS } from './dots'

function Glyph({ g, on }) {
  return (
    <svg viewBox="0 0 50 70" className="led-glyph">
      {DOTS[g].flatMap((row, y) => [...row].map((b, x) => (
        <circle key={`${x}-${y}`} cx={5 + x * 10} cy={5 + y * 10} r="3.6" className={b === '1' && on ? 'on' : 'off'} />
      )))}
    </svg>
  )
}

export default function LedDisplay({ floor, dir }) {
  const label = floor === 0 ? 'T' : String(floor)
  return (
    <div className="led" role="status" aria-label={floor === 0 ? 'Piano terra' : `Piano ${floor}`}>
      <span className={`led-dir ${dir ? 'moving' : ''}`}><Glyph g="U" on={!!dir} /></span>
      <Glyph g={label} on />
    </div>
  )
}
